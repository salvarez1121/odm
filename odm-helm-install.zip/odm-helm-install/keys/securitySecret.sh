oc delete secret odm-tls-cert
oc create secret generic odm-tls-cert --from-literal=keystore_password=changeme --from-file=keystore.jks=keystore.jks --from-literal=truststore_password=changeme --from-file=truststore.jks=truststore.jks
