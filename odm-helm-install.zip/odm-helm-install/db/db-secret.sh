oc delete secret db-secret
oc create secret generic db-secret --from-literal=db-user=odmdb --from-literal=db-password=odmpw
